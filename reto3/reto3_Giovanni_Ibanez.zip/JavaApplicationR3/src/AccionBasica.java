public interface AccionBasica {

    public void Cantar();

    public void Caminar();

    public void Correr();
}
