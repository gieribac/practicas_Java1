public interface AccionEspecialzada {

    public void Hablar();

    public void Bailar();

    public void Trabajar();
}
